/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          lime: '#9CC03F',
          'lime-dark': '#84A532',
          'lime-light': '#B4D460',
          cyan: '#3FB5C7',
          'cyan-dark': '#2E97A7',
          'cyan-light': '#6BC9D7',
          gray: '#6B6B6B',
          'gray-soft': '#A8A8A8',
        },
        canvas: {
          deep: '#0d3b35',
          'deep-dark': '#082621',
          'deep-light': '#155749',
          cream: '#f5f1e8',
          ink: '#0a1f1c',
          mist: '#e8ede9',
        },
        primary: '#3FB5C7',
        accent: '#9CC03F',
      },
      fontFamily: {
        display: ['Fraunces', 'Georgia', 'serif'],
        body: ['Inter', 'system-ui', 'sans-serif'],
      },
      borderRadius: {
        '2xl': '16px',
      },
      boxShadow: {
        tinted: '0 8px 30px rgba(13,59,53,0.08)',
      },
      keyframes: {
        pulse_slow: {
          '0%, 100%': { transform: 'scale(1)', opacity: '1' },
          '50%': { transform: 'scale(1.12)', opacity: '0.85' },
        },
      },
      animation: {
        'pulse-slow': 'pulse_slow 2.5s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};
