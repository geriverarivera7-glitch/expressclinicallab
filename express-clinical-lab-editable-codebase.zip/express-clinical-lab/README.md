# Express Clinical Lab — Marketing Website

Bilingual (ES/EN) static marketing site for Express Clinical Lab, Guayama, Puerto Rico.

## Stack

- Vite + React 19 + TypeScript
- Tailwind CSS v3 with custom brand theme
- Framer Motion for animations
- react-router-dom v7 — `/es/*` and `/en/*` routes
- react-i18next — translation files in `src/locales/`
- react-helmet-async — per-page SEO meta tags
- lucide-react — icons

## Setup

```bash
npm install
npm run dev       # http://localhost:5173
npm run build     # production build → dist/
npm run preview   # preview the production build
```

For future edits, see [EDITING.md](./EDITING.md).

## Deploy to Vercel

1. Push this repo to GitHub
2. Import the repo at vercel.com
3. Framework: Vite (auto-detected)
4. No environment variables needed
5. `vercel.json` handles SPA fallback routing

## Updating content

### Text copy
Edit `src/locales/es/common.json` (Spanish) and `src/locales/en/common.json` (English).

### Logo
Replace `src/assets/logo.png` with updated file (same name).

### Homepage hero image
Replace `src/assets/home-hero-care.jpg`, or update the import in `src/pages/Home.tsx`.

### Hours of operation
Update `loc1Hours` / `loc2Hours` in both translation files.

### Client logos
Replace placeholder strings in the `clients` array with `<img>` tags once files are available.

### Real photography
Replace Unsplash URLs with production photos.

### Appointment booking (future)
Embed NexHealth widget or add a `/citas` route.

### Results portal (future)
Add a MisResultados.com link in nav and footer.

## What's still placeholder

| Item | Where to update |
|------|----------------|
| Contact form endpoint | Form submit handlers in `src/pages/Contact.tsx`, `src/pages/AtHomeService.tsx`, `src/pages/ForBusinesses.tsx` |
| Appointment booking | Add a route/widget when the provider is chosen |
| Final legal/privacy review | `src/locales/*/common.json` → `privacy` |

## Routing

| Spanish | English |
|---------|---------|
| `/es/` | `/en/` |
| `/es/servicios` | `/en/servicios` |
| `/es/pruebas` | `/en/pruebas` |
| `/es/domicilio` | `/en/domicilio` |
| `/es/empresas` | `/en/empresas` |
| `/es/localidades` | `/en/localidades` |
| `/es/nosotros` | `/en/nosotros` |
| `/es/contacto` | `/en/contacto` |
| `/es/privacidad` | `/en/privacidad` |

Legacy `/ubicaciones` redirects to `/localidades`. Language preference persists in `localStorage` key `lang`, but direct `/es/*` or `/en/*` URLs take priority.
