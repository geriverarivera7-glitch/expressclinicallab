# Express Clinical Lab — Brand Reference

## Color Tokens (Tailwind)

### Logo Palette
| Token | Hex | Usage |
|-------|-----|-------|
| `brand-lime` | `#9CC03F` | Primary CTA buttons, active nav, eyebrow accents |
| `brand-lime-dark` | `#84A532` | Hover state for lime buttons |
| `brand-lime-light` | `#B4D460` | Soft lime accents |
| `brand-cyan` | `#3FB5C7` | Secondary CTAs, links, "Clinical Lab" color |
| `brand-cyan-dark` | `#2E97A7` | Hover state for cyan elements |
| `brand-cyan-light` | `#6BC9D7` | Soft cyan accents |
| `brand-gray` | `#6B6B6B` | "Express" wordmark gray |
| `brand-gray-soft` | `#A8A8A8` | DNA dots, muted labels |

### Marketing Canvas
| Token | Hex | Usage |
|-------|-----|-------|
| `canvas-deep` | `#0d3b35` | Primary dark teal background (hero, dark sections) |
| `canvas-deep-dark` | `#082621` | Footer, deepest backgrounds |
| `canvas-deep-light` | `#155749` | Gradient highlights, card hover on dark |
| `canvas-cream` | `#f5f1e8` | Warm off-white sections |
| `canvas-ink` | `#0a1f1c` | Near-black text on light backgrounds |
| `canvas-mist` | `#e8ede9` | Subtle dividers |

## Button Variants

```tsx
// Primary CTA — loudest action
<Button variant="lime">Cotizar por WhatsApp</Button>
// bg-brand-lime text-canvas-ink hover:bg-brand-lime-dark

// Secondary CTA
<Button variant="cyan">Ver servicios</Button>
// bg-brand-cyan text-white hover:bg-brand-cyan-dark

// Ghost — on dark backgrounds
<Button variant="ghost">Conoce nuestros servicios</Button>
// border border-white/30 text-white hover:bg-white/10

// Cyan outline — on light backgrounds
<Button variant="cyan-outline">Llamar 787-558-0632</Button>
// border-2 border-brand-cyan text-brand-cyan hover:bg-brand-cyan hover:text-white
```

## Typography

| Role | Font | Weight | Size |
|------|------|--------|------|
| Hero h1 | Fraunces | 600 | `clamp(3rem, 7vw, 6.5rem)` |
| Section h2 | Fraunces | 600 | `clamp(2.25rem, 4.5vw, 4rem)` |
| Card titles | Fraunces | 600 | `text-lg`–`text-2xl` |
| Eyebrow labels | Inter | 600 | `12px`, uppercase, `0.15em` tracking |
| Body text | Inter | 400 | `1.0625rem` / `17px`, line-height `1.65` |
| Stat numerals | Fraunces italic | 600 | `text-5xl`–`text-6xl` |

Use `className="font-display"` for Fraunces, `className="font-body"` for Inter.  
Use `className="eyebrow"` utility for eyebrow labels.

## Animations (Framer Motion)

```ts
// Standard fade-up on scroll
{
  initial: { opacity: 0, y: 40 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-100px' },
  transition: { duration: 0.8, ease: [0.22, 1, 0.36, 1] }
}
// Stagger children: delay each by 0.08s
```

## Hero Section Pattern

```tsx
<section
  className="relative min-h-screen bg-canvas-deep"
  style={{ background: 'radial-gradient(ellipse at 80% 20%, #155749 0%, #0d3b35 55%, #082621 100%)' }}
>
  <DNAPattern className="absolute top-16 right-8 opacity-60" />
  <WaveLine className="absolute bottom-0" />
  {/* content */}
</section>
```

## Card Patterns

```tsx
// Card on dark background
"bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl"

// Card on light background
"bg-white rounded-2xl border border-canvas-ink/5 shadow-tinted"

// Accent icon badge
"w-10 h-10 rounded-full bg-brand-lime/10 border border-brand-lime/30 flex items-center justify-center"
```

## Logo Usage

- **Over dark sections:** wrap in `bg-white px-3 py-1.5 rounded-xl shadow-sm`
- **Over white/light:** display directly, no pill
- **Minimum height:** 36px mobile, 44px desktop
- **File:** `src/assets/logo.png`

## WhatsApp Deep Links

| Context | URL |
|---------|-----|
| General info | `https://wa.me/19392945372?text=Hola%2C%20quisiera%20información` |
| Quote request | `https://wa.me/19392945372?text=Hola%20Express%20Clinical%20Lab%2C%20quisiera%20cotizar` |
| Jerry Rivera (corporate) | `https://wa.me/17872404208?text=Hola%20Jerry%2C%20quisiera%20una%20propuesta%20para%20mi%20empresa` |
| At-home service | `https://wa.me/19392945372?text=Hola%2C%20quisiera%20agendar%20servicio%20a%20domicilio` |
