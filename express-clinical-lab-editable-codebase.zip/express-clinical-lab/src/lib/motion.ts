import type { Variants } from 'framer-motion';

export const APPLE_EASE: [number, number, number, number] = [0.22, 1, 0.36, 1];

// Standard fade-up for sections — slower, more deliberate than typical
export const fadeUp = (delay = 0, duration = 1.1) => ({
  initial: { opacity: 0, y: 32 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-80px' },
  transition: { duration, delay, ease: APPLE_EASE },
});

// Hero entrance — only on first paint, not scroll
export const heroFade = (delay = 0) => ({
  initial: { opacity: 0, y: 24 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 1.2, delay, ease: APPLE_EASE },
});

export const staggerContainer: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08, delayChildren: 0.1 } },
};

export const staggerItem: Variants = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.9, ease: APPLE_EASE } },
};
