import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import es from '../locales/es/common.json';
import en from '../locales/en/common.json';

const pathLang = window.location.pathname.match(/^\/(es|en)(\/|$)/)?.[1];
const savedLang = pathLang || localStorage.getItem('lang') || 'es';
localStorage.setItem('lang', savedLang);

i18n
  .use(initReactI18next)
  .init({
    resources: {
      es: { common: es },
      en: { common: en },
    },
    lng: savedLang,
    fallbackLng: 'es',
    defaultNS: 'common',
    interpolation: { escapeValue: false },
  });

i18n.on('languageChanged', (lng) => localStorage.setItem('lang', lng));

export default i18n;
