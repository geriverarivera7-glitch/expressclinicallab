import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Suspense, lazy } from 'react';
import ScrollToTop from './components/ScrollToTop';

// Lazy-load pages — each route ships its own JS chunk
const HomePage           = lazy(() => import('./pages/Home'));
const AboutPage          = lazy(() => import('./pages/About'));
const ServicesPage       = lazy(() => import('./pages/Services'));
const TestsPage          = lazy(() => import('./pages/Tests'));
const AtHomeServicePage  = lazy(() => import('./pages/AtHomeService'));
const ForBusinessesPage  = lazy(() => import('./pages/ForBusinesses'));
const LocationsPage      = lazy(() => import('./pages/Locations'));
const ContactPage        = lazy(() => import('./pages/Contact'));
const PrivacyNoticePage  = lazy(() => import('./pages/PrivacyNotice'));

// Pre-paint loading sliver — matches the deep teal so there's no flash
const PageFallback = () => <div className="min-h-screen bg-canvas-deep" aria-hidden="true" />;

function AppRoutes({ lang }: { lang: 'es' | 'en' }) {
  return (
    <Routes>
      <Route index                         element={<HomePage />} />
      <Route path="nosotros"               element={<AboutPage />} />
      <Route path="servicios"              element={<ServicesPage />} />
      <Route path="pruebas"                element={<TestsPage />} />
      <Route path="domicilio"              element={<AtHomeServicePage />} />
      <Route path="empresas"               element={<ForBusinessesPage />} />
      <Route path="localidades"            element={<LocationsPage />} />
      <Route path="contacto"               element={<ContactPage />} />
      <Route path="privacidad"             element={<PrivacyNoticePage />} />
      {/* Legacy redirect — old /ubicaciones URLs */}
      <Route path="ubicaciones"            element={<Navigate to={`/${lang}/localidades`} replace />} />
      <Route path="*"                      element={<Navigate to={`/${lang}/`} replace />} />
    </Routes>
  );
}

export default function App() {
  const savedLang = (localStorage.getItem('lang') as 'es' | 'en') || 'es';

  return (
    <BrowserRouter>
      <ScrollToTop />
      <Suspense fallback={<PageFallback />}>
        <Routes>
          <Route path="/"        element={<Navigate to={`/${savedLang}/`} replace />} />
          <Route path="/es/*"    element={<AppRoutes lang="es" />} />
          <Route path="/en/*"    element={<AppRoutes lang="en" />} />
          <Route path="*"        element={<Navigate to={`/${savedLang}/`} replace />} />
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}
