import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Phone, MessageCircle, Mail, MapPin, FileText, ExternalLink } from 'lucide-react';
import logoWhite from '../assets/logo-white.svg';

const MISRESULTADOS_URL = 'https://www.misresultados.com';

export default function Footer() {
  const { t, i18n } = useTranslation();
  const lang = i18n.language;

  const navLinks = [
    { key: 'nav.home', to: `/${lang}/` },
    { key: 'nav.about', to: `/${lang}/nosotros` },
    { key: 'nav.services', to: `/${lang}/servicios` },
    { key: 'nav.tests', to: `/${lang}/pruebas` },
    { key: 'nav.athome', to: `/${lang}/domicilio` },
    { key: 'nav.businesses', to: `/${lang}/empresas` },
    { key: 'nav.locations', to: `/${lang}/localidades` },
    { key: 'nav.contact', to: `/${lang}/contacto` },
  ];

  return (
    <footer className="bg-canvas-deep-dark text-white">
      <div className="max-w-7xl mx-auto px-5 md:px-8 pt-20 pb-10">
        {/* Top — tagline */}
        <div className="border-b border-white/10 pb-12 mb-12 grid md:grid-cols-2 gap-8 items-end">
          <div>
            <img src={logoWhite} alt="Express Clinical Lab" className="h-9 w-auto mb-5" width={180} height={36} />
            <p className="font-display text-2xl md:text-3xl font-medium max-w-md leading-tight text-white/95">
              {t('footer.tagline')}
            </p>
          </div>
          <div className="flex md:justify-end gap-3">
            {[
              { label: 'WhatsApp', href: 'https://wa.me/19392945372', svg: (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
              )},
              { label: 'Instagram', href: 'https://www.instagram.com/expressclinicallab.pr/', svg: (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><rect x="2" y="2" width="20" height="20" rx="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
              )},
              { label: 'Facebook', href: 'https://www.facebook.com/ExpressClinicalLab', svg: (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
              )},
            ].map((s) => (
              <a
                key={s.label}
                href={s.href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={s.label}
                className="w-10 h-10 rounded-full border border-white/15 flex items-center justify-center text-white/70 hover:text-brand-lime hover:border-brand-lime/60 transition-all duration-300"
              >
                {s.svg}
              </a>
            ))}
          </div>
        </div>

        {/* Middle — 3 columns */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12 text-sm">
          <div>
            <h3 className="eyebrow text-white/40 mb-5">{t('footer.quickLinks')}</h3>
            <ul className="flex flex-col gap-3">
              {navLinks.map(({ key, to }) => (
                <li key={key}>
                  <Link to={to} className="text-white/70 hover:text-white transition-colors duration-200">
                    {t(key)}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="eyebrow text-white/40 mb-5">{t('footer.contact')}</h3>
            <ul className="flex flex-col gap-4">
              <li>
                <a href="tel:7875580632" className="flex items-start gap-3 text-white/70 hover:text-white transition-colors duration-200">
                  <Phone size={15} className="text-brand-lime mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-white/40 text-xs">Teléfono</p>
                    <p>{t('footer.phone')}</p>
                  </div>
                </a>
              </li>
              <li>
                <a href="https://wa.me/19392945372" target="_blank" rel="noopener noreferrer" className="flex items-start gap-3 text-white/70 hover:text-white transition-colors duration-200">
                  <MessageCircle size={15} className="text-brand-lime mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-white/40 text-xs">WhatsApp</p>
                    <p>{t('footer.whatsapp')}</p>
                  </div>
                </a>
              </li>
              <li>
                <a href="mailto:expressclinicallab@gmail.com" className="flex items-start gap-3 text-white/70 hover:text-white transition-colors duration-200">
                  <Mail size={15} className="text-brand-lime mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-white/40 text-xs">Email general</p>
                    <p className="break-all">{t('footer.email')}</p>
                  </div>
                </a>
              </li>
              <li>
                <a href="mailto:jlriveraandsons@gmail.com" className="flex items-start gap-3 text-white/70 hover:text-white transition-colors duration-200">
                  <Mail size={15} className="text-brand-lime mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-white/40 text-xs">Email empresas</p>
                    <p className="break-all">{t('footer.emailBusiness')}</p>
                  </div>
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="eyebrow text-white/40 mb-5">Localidades</h3>
            <div className="flex items-start gap-3 text-white/70 text-sm">
              <MapPin size={15} className="text-brand-lime mt-0.5 flex-shrink-0" />
              <p>{t('footer.address')}</p>
            </div>
            <p className="text-white/70 text-sm mt-4">{t('footer.hours')}</p>

            {/* Patient results — MisResultados secure portal */}
            <a
              href={MISRESULTADOS_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-8 inline-flex items-center gap-3 text-white/80 hover:text-brand-lime transition-colors duration-300 group"
            >
              <div className="w-9 h-9 rounded-full bg-brand-lime/10 border border-brand-lime/30 flex items-center justify-center group-hover:bg-brand-lime/20 transition-colors">
                <FileText size={14} className="text-brand-lime" strokeWidth={1.75} />
              </div>
              <div>
                <p className="text-white/40 text-xs flex items-center gap-1">
                  {t('footer.resultsSub')}
                  <ExternalLink size={10} strokeWidth={2} />
                </p>
                <p className="text-sm font-medium">{t('footer.results')}</p>
              </div>
            </a>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-white/10 pt-6 flex flex-col md:flex-row justify-between items-center gap-3 text-xs text-white/40">
          <p>{t('footer.copyright')}</p>
          <Link to={`/${lang}/privacidad`} className="hover:text-white/70 transition-colors">
            {t('footer.privacy')}
          </Link>
        </div>
      </div>
    </footer>
  );
}
