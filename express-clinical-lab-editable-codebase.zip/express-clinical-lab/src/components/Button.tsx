import type { ReactNode } from 'react';

interface Props {
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'ghost' | 'lime' | 'cyan' | 'cyan-outline';
  size?: 'sm' | 'md' | 'lg';
  href?: string;
  onClick?: () => void;
  className?: string;
  target?: string;
  rel?: string;
  type?: 'button' | 'submit';
}

const base =
  'inline-flex items-center justify-center gap-2 font-medium rounded-full ' +
  'transition-all duration-300 ease-apple ' +
  'focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2';

const sizes = {
  sm: 'text-sm px-5 py-2.5',
  md: 'text-base px-7 py-3.5',
  lg: 'text-base px-8 py-4',
};

const variants: Record<string, string> = {
  // Refined dark primary — Apple's preferred CTA style
  primary: 'bg-canvas-ink text-white hover:bg-canvas-deep focus-visible:ring-canvas-ink/40 hover:-translate-y-px',
  // Subtle on-light secondary
  secondary: 'bg-white text-canvas-ink border border-canvas-ink/15 hover:border-canvas-ink/30 hover:bg-canvas-cream focus-visible:ring-canvas-ink/20',
  // Minimal on-dark
  ghost: 'border border-white/20 text-white hover:bg-white/8 hover:border-white/40 focus-visible:ring-white/30',
  // Lime — accent CTA
  lime: 'bg-brand-lime text-canvas-ink hover:bg-brand-lime-dark focus-visible:ring-brand-lime/40 hover:-translate-y-px',
  cyan: 'bg-brand-cyan text-white hover:bg-brand-cyan-dark focus-visible:ring-brand-cyan/40 hover:-translate-y-px',
  'cyan-outline': 'border border-brand-cyan text-brand-cyan hover:bg-brand-cyan hover:text-white focus-visible:ring-brand-cyan/30',
};

export default function Button({
  children,
  variant = 'primary',
  size = 'md',
  href,
  onClick,
  className = '',
  target,
  rel,
  type = 'button',
}: Props) {
  const cls = `${base} ${sizes[size]} ${variants[variant]} ${className}`;
  if (href) return <a href={href} target={target} rel={rel} className={cls}>{children}</a>;
  return <button type={type} onClick={onClick} className={cls}>{children}</button>;
}
