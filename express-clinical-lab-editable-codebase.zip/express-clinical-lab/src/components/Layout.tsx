import type { ReactNode } from 'react';
import Header from './Header';
import Footer from './Footer';
import WhatsAppFloat from './WhatsAppFloat';

export default function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      {/* Skip-to-content — visible only when keyboard-focused */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-50 focus:bg-canvas-ink focus:text-white focus:px-4 focus:py-2 focus:rounded-full focus:text-sm focus:font-medium"
      >
        Saltar al contenido
      </a>
      <Header />
      <main id="main-content" className="flex-1">{children}</main>
      <Footer />
      <WhatsAppFloat />
    </div>
  );
}
