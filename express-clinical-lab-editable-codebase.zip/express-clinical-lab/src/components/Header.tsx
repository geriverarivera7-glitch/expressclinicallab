import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Menu, X, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import logoDefault from '../assets/logo.svg';
import logoWhite from '../assets/logo-white.svg';
import LanguageToggle from './LanguageToggle';

const WA_QUOTE =
  'https://wa.me/19392945372?text=Hola%20Express%20Clinical%20Lab%2C%20quisiera%20información';

// MisResultados secure patient portal — opens in a new tab so the marketing
// site never sees or stores any PHI. If the lab has a custom MisResultados
// subdomain, swap this URL.
const MISRESULTADOS_URL = 'https://www.misresultados.com';

export default function Header() {
  const { t, i18n } = useTranslation();
  const location = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const lang = i18n.language;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const nav = [
    { key: 'nav.home', to: `/${lang}/` },
    { key: 'nav.about', to: `/${lang}/nosotros` },
    { key: 'nav.services', to: `/${lang}/servicios` },
    { key: 'nav.tests', to: `/${lang}/pruebas` },
    { key: 'nav.athome', to: `/${lang}/domicilio` },
    { key: 'nav.businesses', to: `/${lang}/empresas` },
    { key: 'nav.locations', to: `/${lang}/localidades` },
    { key: 'nav.contact', to: `/${lang}/contacto` },
  ];

  // Pages with a dark teal hero use the white header treatment until scroll.
  const isHome = location.pathname === `/${lang}/` || location.pathname === `/${lang}`;
  const hasDarkHero = !location.pathname.endsWith('/privacidad');
  const useDarkHeader = !scrolled && (hasDarkHero || isHome);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ease-apple ${
        scrolled
          ? 'bg-white/85 backdrop-blur-xl border-b border-canvas-ink/8'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 md:h-[72px] flex items-center justify-between gap-4">
        {/* Logo */}
        <Link to={`/${lang}/`} onClick={() => setOpen(false)} className="flex-shrink-0" aria-label="Express Clinical Lab">
          <img
            src={useDarkHeader ? logoWhite : logoDefault}
            alt="Express Clinical Lab"
            className="h-8 md:h-9 w-auto object-contain transition-opacity duration-300"
            width={200}
            height={36}
          />
        </Link>

        {/* Desktop nav */}
        <nav className="hidden xl:flex items-center gap-0.5" aria-label="Main">
          {nav.map(({ key, to }) => {
            const active =
              location.pathname === to ||
              location.pathname === to.replace(/\/$/, '');
            return (
              <Link
                key={key}
                to={to}
                className={`px-3 py-2 text-[13px] font-medium rounded-full transition-colors duration-200 ${
                  useDarkHeader
                    ? active
                      ? 'text-white'
                      : 'text-white/70 hover:text-white'
                    : active
                    ? 'text-canvas-ink'
                    : 'text-canvas-ink/60 hover:text-canvas-ink'
                }`}
              >
                {t(key)}
              </Link>
            );
          })}
        </nav>

        {/* Right controls */}
        <div className="hidden xl:flex items-center gap-2">
          <LanguageToggle dark={useDarkHeader} />
          {/* Patient results — secure portal in new tab */}
          <a
            href={MISRESULTADOS_URL}
            target="_blank"
            rel="noopener noreferrer"
            className={`inline-flex items-center gap-1.5 text-[13px] font-medium px-3.5 py-2 rounded-full transition-all duration-300 ease-apple ${
              useDarkHeader
                ? 'text-white/80 hover:text-white hover:bg-white/10'
                : 'text-canvas-ink/70 hover:text-canvas-ink hover:bg-canvas-cream'
            }`}
            title={t('nav.results')}
          >
            <FileText size={13} strokeWidth={1.75} />
            {t('nav.results')}
          </a>
          <a
            href={WA_QUOTE}
            target="_blank"
            rel="noopener noreferrer"
            className={`text-[13px] font-medium px-4 py-2 rounded-full transition-all duration-300 ${
              useDarkHeader
                ? 'bg-white text-canvas-ink hover:bg-brand-lime'
                : 'bg-canvas-ink text-white hover:bg-canvas-deep'
            }`}
          >
            {t('nav.cta')}
          </a>
        </div>

        {/* Mobile hamburger */}
        <button
          className={`xl:hidden p-2 -mr-2 ${useDarkHeader ? 'text-white' : 'text-canvas-ink'}`}
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile drawer */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="xl:hidden fixed inset-0 top-16 bg-white z-30 flex flex-col"
          >
            <nav className="flex-1 px-6 pt-8 pb-6 flex flex-col">
              {nav.map(({ key, to }, i) => {
                const active =
                  location.pathname === to ||
                  location.pathname === to.replace(/\/$/, '');
                return (
                  <motion.div
                    key={key}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.04, duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                  >
                    <Link
                      to={to}
                      onClick={() => setOpen(false)}
                      className={`font-display text-2xl block py-3 border-b border-canvas-ink/8 ${
                        active ? 'text-canvas-ink' : 'text-canvas-ink/70'
                      }`}
                    >
                      {t(key)}
                    </Link>
                  </motion.div>
                );
              })}
            </nav>
            {/* Patient results — full-width prominent CTA in drawer */}
            <a
              href={MISRESULTADOS_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="mx-6 mb-4 flex items-center justify-center gap-2 bg-brand-lime/15 border border-brand-lime/30 text-canvas-ink text-base font-medium px-5 py-4 rounded-2xl"
            >
              <FileText size={16} strokeWidth={1.75} className="text-brand-lime-dark" />
              {t('nav.results')}
            </a>
            <div className="px-6 py-6 border-t border-canvas-ink/8 flex items-center justify-between bg-canvas-cream">
              <LanguageToggle onChange={() => setOpen(false)} />
              <a
                href={WA_QUOTE}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-canvas-ink text-white text-sm font-medium px-5 py-2.5 rounded-full"
              >
                {t('nav.cta')}
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
