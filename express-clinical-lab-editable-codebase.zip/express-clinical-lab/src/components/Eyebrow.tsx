import type { ReactNode } from 'react';

interface Props {
  children: ReactNode;
  tone?: 'ink' | 'white' | 'lime' | 'cyan';
  className?: string;
}

const tones = {
  ink: 'text-canvas-ink/60',
  white: 'text-white/60',
  lime: 'text-brand-lime',
  cyan: 'text-brand-cyan',
};

export default function Eyebrow({ children, tone = 'ink', className = '' }: Props) {
  return (
    <p className={`eyebrow ${tones[tone]} ${className}`}>{children}</p>
  );
}
