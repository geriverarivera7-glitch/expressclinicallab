import { useTranslation } from 'react-i18next';
import { useNavigate, useLocation } from 'react-router-dom';

export default function LanguageToggle({ dark = false, onChange }: { dark?: boolean; onChange?: () => void }) {
  const { i18n, t } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();

  const toggle = () => {
    const next = i18n.language === 'es' ? 'en' : 'es';
    i18n.changeLanguage(next);
    const newPath = location.pathname.replace(/^\/(es|en)/, `/${next}`);
    navigate(newPath || `/${next}/`);
    onChange?.();
  };

  const active = i18n.language === 'es' ? 'ES' : 'EN';
  const other = t('nav.langToggle');

  return (
    <button
      onClick={toggle}
      className={`text-[11px] font-semibold tracking-wider px-3 py-1.5 rounded-full transition-all duration-300 ease-apple ${
        dark
          ? 'text-white/80 hover:text-white hover:bg-white/8'
          : 'text-canvas-ink/70 hover:text-canvas-ink hover:bg-canvas-cream'
      }`}
      aria-label={`Switch to ${other}`}
    >
      {active} <span className="opacity-30 mx-0.5">/</span> <span className="opacity-50">{other}</span>
    </button>
  );
}
