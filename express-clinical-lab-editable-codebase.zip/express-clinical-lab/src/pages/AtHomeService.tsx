import { useState } from 'react';
import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Helmet } from 'react-helmet-async';
import { Check, MessageCircle, MapPin } from 'lucide-react';
import Layout from '../components/Layout';
import Eyebrow from '../components/Eyebrow';
import Button from '../components/Button';
import { fadeUp, heroFade } from '../lib/motion';

const WA = 'https://wa.me/19392945372?text=Hola%2C%20quisiera%20servicio%20a%20domicilio';

export default function AtHomeServicePage() {
  const { t } = useTranslation();
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    name: '', phone: '', town: '', address: '',
    date: '', time: '', tests: '',
    order: '', insurance: '', notes: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('[At-home request]', form);
    setSubmitted(true);
  };

  const ideal = [
    t('athome.ideal1'),
    t('athome.ideal2'),
    t('athome.ideal3'),
    t('athome.ideal4'),
  ];

  const benefits = [
    t('athome.b1'), t('athome.b2'), t('athome.b3'),
    t('athome.b4'), t('athome.b5'), t('athome.b6'),
  ];

  const areas = t('common.areas', { returnObjects: true }) as string[];

  const inputCls =
    'w-full px-4 py-3 rounded-2xl border border-canvas-ink/12 bg-white text-canvas-ink ' +
    'placeholder-canvas-ink/35 text-[15px] focus:outline-none focus:border-canvas-ink/40 ' +
    'transition-all duration-200';

  const labelCls = 'eyebrow text-canvas-ink/50 mb-2 block';

  return (
    <Layout>
      <Helmet>
        <title>Servicio a Domicilio – Express Clinical Lab</title>
        <meta name="description" content="Servicio de laboratorio a domicilio en el sureste de Puerto Rico. Ideal para adultos mayores y pacientes con movilidad limitada." />
      </Helmet>

      {/* Hero */}
      <section className="bg-canvas-deep relative overflow-hidden">
        <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse 60% 50% at 50% 0%, #155749 0%, #0d3b35 50%, #082621 100%)' }} aria-hidden="true" />
        <div className="relative max-w-4xl mx-auto px-5 md:px-8 pt-40 md:pt-48 pb-24 md:pb-32 text-center">
          <motion.div {...heroFade()}>
            <Eyebrow tone="lime" className="mb-8">{t('athome.heroEyebrow')}</Eyebrow>
          </motion.div>
          <motion.h1 {...heroFade(0.12)} className="text-hero text-white">
            {t('athome.heroTitle')}<br />
            <span className="text-brand-lime">{t('athome.heroAccent')}</span>
          </motion.h1>
          <motion.p {...heroFade(0.24)} className="text-lg md:text-xl text-white/70 mt-8 max-w-prose-tight mx-auto">
            {t('athome.heroSub')}
          </motion.p>
          <motion.div {...heroFade(0.36)} className="mt-12">
            <Button href="#solicitar" variant="lime">
              {t('athome.heroCta')}
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Ideal-for */}
      <section className="bg-white py-32 md:py-40">
        <div className="max-w-5xl mx-auto px-5 md:px-8 text-center">
          <motion.div {...fadeUp()} className="mb-12">
            <h2 className="text-section text-canvas-ink">{t('athome.idealForTitle')}</h2>
          </motion.div>
          <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-6">
            {ideal.map((label, i) => (
              <motion.div key={i} {...fadeUp(i * 0.06)}
                className="bg-canvas-cream rounded-3xl p-8 border border-canvas-ink/5"
              >
                <p className="font-display text-lg md:text-xl font-medium text-canvas-ink leading-tight">
                  {label}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Service areas */}
      <section className="bg-canvas-cream py-32 md:py-40">
        <div className="max-w-5xl mx-auto px-5 md:px-8">
          <motion.div {...fadeUp()} className="text-center mb-16">
            <Eyebrow tone="lime" className="mb-5">{t('athome.areasEyebrow')}</Eyebrow>
            <h2 className="text-section text-canvas-ink">
              {t('athome.areasTitle')} <span className="text-brand-cyan">{t('athome.areasAccent')}</span>
            </h2>
            <p className="text-canvas-ink/60 text-lg mt-6 max-w-prose-tight mx-auto">
              {t('athome.areasSub')}
            </p>
          </motion.div>
          <motion.div {...fadeUp(0.15)} className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {areas.map((area, i) => (
              <div key={i} className="flex items-center gap-2.5 bg-white border border-canvas-ink/8 rounded-2xl px-5 py-4">
                <MapPin size={14} className="text-brand-lime flex-shrink-0" />
                <span className="text-canvas-ink font-medium text-[15px]">{area}</span>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Benefits */}
      <section className="bg-white py-32 md:py-40">
        <div className="max-w-6xl mx-auto px-5 md:px-8 grid md:grid-cols-2 gap-16">
          <motion.div {...fadeUp()}>
            <Eyebrow tone="lime" className="mb-5">{t('athome.benefitsEyebrow')}</Eyebrow>
            <h2 className="text-section text-canvas-ink">
              {t('athome.benefitsTitle')}<br />
              <span className="text-canvas-ink/50">{t('athome.benefitsAccent')}</span>
            </h2>
          </motion.div>
          <motion.div {...fadeUp(0.1)} className="space-y-4">
            {benefits.map((b, i) => (
              <div key={i} className="flex items-start gap-3 border-b border-canvas-ink/8 pb-4 last:border-0">
                <div className="w-6 h-6 rounded-full bg-brand-lime/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Check size={12} className="text-brand-lime-dark" strokeWidth={3} />
                </div>
                <p className="text-canvas-ink text-base md:text-lg">{b}</p>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Form */}
      <section id="solicitar" className="bg-canvas-cream py-32 md:py-40">
        <div className="max-w-3xl mx-auto px-5 md:px-8">
          <motion.div {...fadeUp()} className="mb-12">
            <h2 className="text-section text-canvas-ink mb-4">{t('athome.formTitle')}</h2>
            <p className="text-canvas-ink/60 text-lg leading-relaxed">{t('athome.formSub')}</p>
          </motion.div>

          {submitted ? (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-3xl border border-brand-lime/30 p-10 text-center"
            >
              <div className="w-14 h-14 rounded-full bg-brand-lime/20 flex items-center justify-center mx-auto mb-5">
                <Check size={24} className="text-brand-lime-dark" strokeWidth={2.5} />
              </div>
              <p className="font-display text-2xl font-medium text-canvas-ink">
                {t('athome.formSuccess')}
              </p>
              <div className="mt-8">
                <Button href={WA} target="_blank" rel="noopener noreferrer" variant="primary">
                  <MessageCircle size={16} />
                  WhatsApp
                </Button>
              </div>
            </motion.div>
          ) : (
            <motion.form {...fadeUp(0.1)}
              onSubmit={handleSubmit}
              className="bg-white rounded-3xl border border-canvas-ink/8 p-8 md:p-10 space-y-6"
            >
              <div className="grid md:grid-cols-2 gap-5">
                <div>
                  <label className={labelCls}>{t('athome.formName')}</label>
                  <input required value={form.name} onChange={e => setForm(f => ({...f, name: e.target.value}))} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>{t('athome.formPhone')}</label>
                  <input required type="tel" value={form.phone} onChange={e => setForm(f => ({...f, phone: e.target.value}))} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>{t('athome.formTown')}</label>
                  <input required value={form.town} onChange={e => setForm(f => ({...f, town: e.target.value}))} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>{t('athome.formAddress')}</label>
                  <input required value={form.address} onChange={e => setForm(f => ({...f, address: e.target.value}))} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>{t('athome.formDate')}</label>
                  <input type="date" required value={form.date} onChange={e => setForm(f => ({...f, date: e.target.value}))} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>{t('athome.formTime')}</label>
                  <input type="time" required value={form.time} onChange={e => setForm(f => ({...f, time: e.target.value}))} className={inputCls} />
                </div>
              </div>

              <div>
                <label className={labelCls}>{t('athome.formTests')}</label>
                <input value={form.tests} onChange={e => setForm(f => ({...f, tests: e.target.value}))} className={inputCls} placeholder="—" />
              </div>

              <div className="grid md:grid-cols-2 gap-5">
                <div>
                  <label className={labelCls}>{t('athome.formOrder')}</label>
                  <select required value={form.order} onChange={e => setForm(f => ({...f, order: e.target.value}))} className={inputCls}>
                    <option value="">—</option>
                    <option value="yes">{t('athome.formOptionYes')}</option>
                    <option value="no">{t('athome.formOptionNo')}</option>
                    <option value="maybe">{t('athome.formOptionMaybe')}</option>
                  </select>
                </div>
                <div>
                  <label className={labelCls}>{t('athome.formInsurance')}</label>
                  <select required value={form.insurance} onChange={e => setForm(f => ({...f, insurance: e.target.value}))} className={inputCls}>
                    <option value="">—</option>
                    <option value="yes">{t('athome.formOptionYes')}</option>
                    <option value="no">{t('athome.formOptionNo')}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className={labelCls}>{t('athome.formNotes')}</label>
                <textarea rows={3} value={form.notes} onChange={e => setForm(f => ({...f, notes: e.target.value}))} className={`${inputCls} resize-none`} />
              </div>

              <p className="text-canvas-ink/40 text-xs italic leading-relaxed border-t border-canvas-ink/8 pt-5">
                {t('athome.formDisclaimer')}
              </p>

              <Button type="submit" variant="primary" className="w-full justify-center">
                {t('athome.formSubmit')}
              </Button>
            </motion.form>
          )}
        </div>
      </section>
    </Layout>
  );
}
