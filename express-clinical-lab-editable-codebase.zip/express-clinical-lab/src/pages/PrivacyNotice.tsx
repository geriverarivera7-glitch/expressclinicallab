import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { ArrowLeft, Shield } from 'lucide-react';
import Layout from '../components/Layout';

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] as [number,number,number,number] },
});

export default function PrivacyNoticePage() {
  const { t, i18n } = useTranslation();
  const lang = i18n.language;
  const rights: string[] = t('privacy.s2Rights', { returnObjects: true }) as string[];

  return (
    <Layout>
      <Helmet>
        <title>{`${t('privacy.title')} - Express Clinical Lab`}</title>
        <meta name="description" content="Aviso de Privacidad HIPAA de Express Clinical Lab. Notice of Privacy Practices." />
      </Helmet>

      <section className="pt-32 pb-24 bg-canvas-cream">
        <div className="max-w-3xl mx-auto px-4 md:px-6">
          <motion.div {...fadeUp()}>
            <Link to={`/${lang}/`} className="inline-flex items-center gap-2 text-brand-cyan text-sm hover:text-brand-cyan-dark mb-8 transition-colors">
              <ArrowLeft size={16} />
              {t('privacy.backHome')}
            </Link>

            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-full bg-brand-lime/20 flex items-center justify-center">
                <Shield size={18} className="text-brand-lime" />
              </div>
              <p className="eyebrow text-brand-lime text-xs">HIPAA</p>
            </div>

            <h1 className="font-display text-4xl md:text-5xl font-semibold text-canvas-ink mb-2">
              {t('privacy.title')}
            </h1>
            <p className="text-brand-cyan font-medium mb-2">{t('privacy.subtitle')}</p>
            <p className="text-canvas-ink/50 text-sm mb-10">{t('privacy.effective')}</p>

            <div className="bg-white rounded-2xl p-8 border border-canvas-ink/5 shadow-sm space-y-8 text-canvas-ink/80 leading-relaxed">
              <p>{t('privacy.intro')}</p>

              <div>
                <h2 className="font-display text-xl font-semibold text-canvas-ink mb-3">{t('privacy.s1Title')}</h2>
                <p>{t('privacy.s1Body')}</p>
              </div>

              <div>
                <h2 className="font-display text-xl font-semibold text-canvas-ink mb-3">{t('privacy.s2Title')}</h2>
                <ul className="list-none flex flex-col gap-2">
                  {rights.map((r, i) => (
                    <li key={i} className="flex gap-2 items-start text-sm">
                      <span className="text-brand-lime mt-0.5">✓</span>
                      {r}
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h2 className="font-display text-xl font-semibold text-canvas-ink mb-3">{t('privacy.s3Title')}</h2>
                <p className="mb-4">{t('privacy.s3Body')}</p>
                <div className="bg-canvas-cream rounded-xl p-4 border border-canvas-ink/5 text-sm space-y-2">
                  <p><span className="font-semibold text-canvas-ink">HHS:</span> {t('privacy.hhs')}</p>
                  <p><span className="font-semibold text-canvas-ink">Express Clinical Lab:</span> {t('privacy.officer')}</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
}
