import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { ArrowRight, FlaskConical, Home as HomeIcon, Briefcase, Stethoscope, Heart } from 'lucide-react';
import Layout from '../components/Layout';
import Eyebrow from '../components/Eyebrow';
import { fadeUp, heroFade } from '../lib/motion';

export default function ServicesPage() {
  const { t, i18n } = useTranslation();
  const lang = i18n.language;

  const services = [
    { icon: FlaskConical, title: t('services.s1Title'), body: t('services.s1Body'), link: `/${lang}/pruebas`, linkLabel: t('services.s1Link') },
    { icon: HomeIcon,     title: t('services.s2Title'), body: t('services.s2Body'), link: `/${lang}/domicilio`, linkLabel: t('services.s2Link') },
    { icon: Briefcase,    title: t('services.s3Title'), body: t('services.s3Body'), link: `/${lang}/empresas`,  linkLabel: t('services.s3Link') },
    { icon: Stethoscope,  title: t('services.s4Title'), body: t('services.s4Body'), link: `/${lang}/contacto`,  linkLabel: t('services.s4Link') },
    { icon: Heart,        title: t('services.s5Title'), body: t('services.s5Body'), link: `/${lang}/contacto`,  linkLabel: t('services.s5Link') },
  ];

  return (
    <Layout>
      <Helmet>
        <title>Servicios – Express Clinical Lab</title>
        <meta name="description" content="Cinco maneras de servirte: en el laboratorio, a domicilio, para empresas, para clínicas, con o sin plan médico." />
      </Helmet>

      {/* Hero */}
      <section className="bg-canvas-deep relative overflow-hidden">
        <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse 60% 50% at 50% 0%, #155749 0%, #0d3b35 50%, #082621 100%)' }} aria-hidden="true" />
        <div className="relative max-w-4xl mx-auto px-5 md:px-8 pt-40 md:pt-48 pb-24 md:pb-32 text-center">
          <motion.div {...heroFade()}>
            <Eyebrow tone="lime" className="mb-8">{t('services.heroEyebrow')}</Eyebrow>
          </motion.div>
          <motion.h1 {...heroFade(0.12)} className="text-hero text-white">
            {t('services.heroTitle')}<br />
            <span className="text-brand-lime">{t('services.heroAccent')}</span>
          </motion.h1>
          <motion.p {...heroFade(0.24)} className="text-lg md:text-xl text-white/70 mt-8 max-w-prose-tight mx-auto">
            {t('services.heroSub')}
          </motion.p>
        </div>
      </section>

      {/* Five-pillar grid */}
      <section className="bg-canvas-cream py-32 md:py-40">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {services.map((s, i) => {
              const Icon = s.icon;
              const isWide = i === services.length - 1 && services.length % 3 !== 0;
              return (
                <motion.div
                  key={i}
                  {...fadeUp(i * 0.06)}
                  className={isWide ? 'lg:col-span-1' : ''}
                >
                  <Link
                    to={s.link}
                    className="group block h-full bg-white rounded-3xl p-8 md:p-10 border border-canvas-ink/8 hover:border-canvas-ink/20 transition-all duration-500 ease-apple hover:-translate-y-1"
                  >
                    <div className="w-11 h-11 rounded-full bg-brand-lime/15 border border-brand-lime/30 flex items-center justify-center mb-6">
                      <Icon size={18} className="text-brand-lime-dark" strokeWidth={1.75} />
                    </div>
                    <h3 className="font-display text-2xl font-medium text-canvas-ink mb-3">
                      {s.title}
                    </h3>
                    <p className="text-canvas-ink/60 leading-relaxed mb-8">{s.body}</p>
                    <span className="inline-flex items-center gap-1.5 text-sm font-medium text-canvas-ink group-hover:text-brand-cyan transition-colors">
                      {s.linkLabel}
                      <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform duration-300" />
                    </span>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
    </Layout>
  );
}
