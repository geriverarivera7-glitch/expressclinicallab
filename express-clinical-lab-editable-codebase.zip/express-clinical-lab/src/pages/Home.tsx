import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { ArrowRight, Phone, MessageCircle, FileText, Lock } from 'lucide-react';
import Layout from '../components/Layout';
import Eyebrow from '../components/Eyebrow';
import Button from '../components/Button';
import { fadeUp, heroFade } from '../lib/motion';
import homeHeroCare from '../assets/home-hero-care.jpg';

const WA_QUOTE =
  'https://wa.me/19392945372?text=Hola%20Express%20Clinical%20Lab%2C%20quisiera%20información';

export default function HomePage() {
  const { t, i18n } = useTranslation();
  const lang = i18n.language;

  const services = [
    { title: t('home.s1Title'), body: t('home.s1Body'), link: `/${lang}/servicios` },
    { title: t('home.s2Title'), body: t('home.s2Body'), link: `/${lang}/domicilio` },
    { title: t('home.s3Title'), body: t('home.s3Body'), link: `/${lang}/empresas` },
    { title: t('home.s4Title'), body: t('home.s4Body'), link: `/${lang}/servicios` },
  ];

  const values = [
    { title: t('home.value1Title'), body: t('home.value1Body') },
    { title: t('home.value2Title'), body: t('home.value2Body') },
    { title: t('home.value3Title'), body: t('home.value3Body') },
  ];

  return (
    <Layout>
      <Helmet>
        <title>Express Clinical Lab – Una familia unida por tu salud</title>
        <meta name="description" content="Laboratorio clínico familiar en Guayama, Puerto Rico. Servicio en sucursal, a domicilio y para empresas en el sureste de PR." />
        <meta property="og:title" content="Express Clinical Lab – Una familia unida por tu salud" />
        <meta property="og:description" content="Laboratorio clínico familiar en Guayama, PR. Servicio cercano, accesible y confiable." />
      </Helmet>

      {/* ═══ HERO — photo-led, preserves the original care moment ═══ */}
      <section className="relative min-h-[760px] md:min-h-[720px] bg-canvas-deep overflow-hidden">
        <img
          src={homeHeroCare}
          alt=""
          className="absolute inset-0 h-full w-full object-cover object-[26%_center] md:object-center"
          aria-hidden="true"
        />
        <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(8,38,33,0.08)_0%,rgba(8,38,33,0.1)_34%,rgba(8,38,33,0.88)_58%,rgba(8,38,33,1)_100%)] md:bg-[linear-gradient(90deg,rgba(8,38,33,0)_0%,rgba(8,38,33,0.04)_34%,rgba(8,38,33,0.38)_52%,rgba(8,38,33,0.9)_100%)]" aria-hidden="true" />

        <div className="relative max-w-7xl mx-auto px-5 md:px-8 pt-[52vh] md:pt-28 pb-16 md:pb-20 grid md:grid-cols-[0.92fr_1fr] items-center min-h-[760px] md:min-h-[720px]">
          <div className="hidden md:block" aria-hidden="true" />

          <div className="md:pl-8 lg:pl-16 text-center md:text-left">
          <motion.div {...heroFade(0.08)}>
            <Eyebrow tone="lime" className="mb-5">{t('home.heroEyebrow')}</Eyebrow>
          </motion.div>

          <motion.h1
            {...heroFade(0.18)}
            className="font-display text-5xl md:text-6xl xl:text-7xl leading-[1.02] font-medium text-white max-w-3xl mx-auto md:mx-0"
          >
            {t('home.heroTitle')}{' '}
            <span className="text-brand-lime">{t('home.heroAccent')}</span>
          </motion.h1>

          <motion.p
            {...heroFade(0.28)}
            className="text-lg md:text-xl text-white/80 mt-6 max-w-prose-tight mx-auto md:mx-0 leading-relaxed"
          >
            {t('home.heroSub')}
          </motion.p>

          <motion.div
            {...heroFade(0.38)}
            className="flex flex-wrap items-center justify-center md:justify-start gap-3 mt-8"
          >
            <Button href={WA_QUOTE} target="_blank" rel="noopener noreferrer" variant="lime" size="md">
              <MessageCircle size={16} />
              {t('home.heroCta1')}
            </Button>
            <Button href={`/${lang}/servicios`} variant="ghost" size="md">
              {t('home.heroCta2')} <ArrowRight size={15} />
            </Button>
          </motion.div>
          </div>
        </div>
      </section>

      {/* ═══ VALUES STRIP — replaces the fictional stats ═══ */}
      <section className="bg-white border-b border-canvas-ink/8">
        <div className="max-w-6xl mx-auto px-5 md:px-8 py-16 md:py-20">
          <motion.div {...fadeUp()} className="text-center mb-12">
            <Eyebrow tone="lime">{t('home.valuesEyebrow')}</Eyebrow>
          </motion.div>
          <div className="grid md:grid-cols-3 gap-12 md:gap-16">
            {values.map((v, i) => (
              <motion.div key={i} {...fadeUp(i * 0.1)} className="text-center md:text-left">
                <h3 className="font-display text-2xl md:text-3xl font-medium text-canvas-ink mb-3">
                  {v.title}
                </h3>
                <p className="text-canvas-ink/60 leading-relaxed max-w-sm mx-auto md:mx-0">
                  {v.body}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══ SERVICES — quiet, image-led grid ═══ */}
      <section className="bg-canvas-cream py-32 md:py-40">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <motion.div {...fadeUp()} className="max-w-3xl mb-16 md:mb-20">
            <Eyebrow tone="lime" className="mb-5">{t('home.servicesEyebrow')}</Eyebrow>
            <h2 className="text-section text-canvas-ink">
              {t('home.servicesTitle')}<br />
              <span className="text-canvas-ink/50">{t('home.servicesAccent')}</span>
            </h2>
            <p className="text-canvas-ink/60 text-lg mt-6 max-w-prose-tight">
              {t('home.servicesSub')}
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 gap-6 md:gap-8">
            {services.map((s, i) => (
              <motion.div key={i} {...fadeUp(i * 0.08)}>
                <Link
                  to={s.link}
                  className="group block bg-white rounded-3xl p-8 md:p-10 border border-canvas-ink/8 hover:border-canvas-ink/20 transition-all duration-500 ease-apple hover:-translate-y-1"
                >
                  <h3 className="font-display text-2xl md:text-3xl font-medium text-canvas-ink mb-3">
                    {s.title}
                  </h3>
                  <p className="text-canvas-ink/60 leading-relaxed mb-6">{s.body}</p>
                  <span className="inline-flex items-center gap-1.5 text-sm font-medium text-canvas-ink group-hover:text-brand-cyan transition-colors duration-300">
                    {t('home.learnMore')}
                    <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform duration-300" />
                  </span>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══ AT-HOME FEATURE — the differentiator ═══ */}
      <section className="bg-white py-32 md:py-40">
        <div className="max-w-6xl mx-auto px-5 md:px-8 grid md:grid-cols-2 gap-16 items-center">
          <motion.div {...fadeUp()}>
            <Eyebrow tone="lime" className="mb-5">{t('home.athomeEyebrow')}</Eyebrow>
            <h2 className="text-section text-canvas-ink">
              {t('home.athomeTitle')}<br />
              <span className="text-brand-cyan">{t('home.athomeAccent')}</span>
            </h2>
            <p className="text-canvas-ink/60 text-lg mt-6 leading-relaxed max-w-prose-tight">
              {t('home.athomeBody')}
            </p>
            <div className="mt-10">
              <Button href={`/${lang}/domicilio`} variant="primary">
                {t('home.athomeCta')} <ArrowRight size={15} />
              </Button>
            </div>
          </motion.div>

          <motion.div {...fadeUp(0.15)}>
            {/* Refined geometric placeholder — subtle, premium */}
            <div className="relative aspect-square rounded-[28px] overflow-hidden bg-gradient-to-br from-canvas-cream via-white to-brand-cyan/10 border border-canvas-ink/5">
              <div className="absolute inset-0 flex items-center justify-center">
                <svg viewBox="0 0 200 200" className="w-3/4 h-3/4 text-canvas-ink/8">
                  <circle cx="100" cy="100" r="90" fill="none" stroke="currentColor" strokeWidth="0.5" />
                  <circle cx="100" cy="100" r="65" fill="none" stroke="currentColor" strokeWidth="0.5" />
                  <circle cx="100" cy="100" r="40" fill="none" stroke="currentColor" strokeWidth="0.5" />
                  <path d="M100,30 Q140,100 100,170 Q60,100 100,30" fill="none" stroke="#9CC03F" strokeWidth="1" opacity="0.6" />
                  <path d="M30,100 Q100,140 170,100 Q100,60 30,100" fill="none" stroke="#3FB5C7" strokeWidth="1" opacity="0.6" />
                </svg>
              </div>
              <div className="absolute inset-x-0 bottom-0 p-8 md:p-10">
                <p className="font-display text-2xl md:text-3xl text-canvas-ink/80 leading-tight">
                  {(t('common.areas', { returnObjects: true }) as string[]).join(' · ')}
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ═══ RESULTS — MisResultados portal ═══ */}
      <section className="bg-canvas-cream py-32 md:py-40 border-y border-canvas-ink/8">
        <div className="max-w-6xl mx-auto px-5 md:px-8 grid md:grid-cols-2 gap-16 items-center">
          <motion.div {...fadeUp()} className="md:order-2">
            {/* Portal preview card */}
            <div className="relative bg-white rounded-[28px] border border-canvas-ink/8 p-8 md:p-10 shadow-[0_24px_60px_-20px_rgba(13,59,53,0.18)]">
              <div className="flex items-start justify-between mb-6">
                <div className="w-11 h-11 rounded-full bg-brand-lime/15 border border-brand-lime/30 flex items-center justify-center">
                  <FileText size={18} className="text-brand-lime-dark" strokeWidth={1.75} />
                </div>
                <div className="inline-flex items-center gap-1.5 text-[11px] font-medium text-canvas-ink/50 bg-canvas-cream rounded-full px-2.5 py-1">
                  <Lock size={10} strokeWidth={2} />
                  HIPAA
                </div>
              </div>
              <p className="eyebrow text-canvas-ink/40 mb-3">MisResultados.com</p>
              <p className="font-display text-2xl md:text-3xl font-medium text-canvas-ink leading-tight mb-6">
                Acceso seguro 24/7 a tu historial de pruebas.
              </p>
              <div className="space-y-3 border-t border-canvas-ink/8 pt-6">
                {['Resultados disponibles las 24 horas', 'Acceso protegido bajo HIPAA', 'Historial de pruebas anteriores'].map((line, i) => (
                  <div key={i} className="flex items-center gap-2.5 text-canvas-ink/70 text-[15px]">
                    <span className="w-1 h-1 rounded-full bg-brand-lime" />
                    {line}
                  </div>
                ))}
              </div>
            </div>
          </motion.div>

          <motion.div {...fadeUp(0.1)} className="md:order-1">
            <Eyebrow tone="lime" className="mb-5">{t('home.resultsEyebrow')}</Eyebrow>
            <h2 className="text-section text-canvas-ink">
              {t('home.resultsTitle')}<br />
              <span className="text-brand-cyan">{t('home.resultsAccent')}</span>
            </h2>
            <p className="text-canvas-ink/60 text-lg mt-6 leading-relaxed max-w-prose-tight">
              {t('home.resultsBody')}
            </p>
            <div className="mt-10 flex flex-wrap items-center gap-4">
              <Button
                href="https://www.misresultados.com"
                target="_blank"
                rel="noopener noreferrer"
                variant="primary"
              >
                <FileText size={15} strokeWidth={1.75} />
                {t('home.resultsCta')} <ArrowRight size={15} />
              </Button>
              <p className="text-canvas-ink/40 text-sm">{t('home.resultsNote')}</p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ═══ TRUST — quote section, dark teal accent ═══ */}
      <section className="bg-canvas-deep relative overflow-hidden">
        <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at 50% 50%, #155749 0%, #0d3b35 80%)' }} aria-hidden="true" />
        <div className="relative max-w-4xl mx-auto px-5 md:px-8 py-32 md:py-40 text-center">
          <motion.div {...fadeUp()}>
            <Eyebrow tone="lime" className="mb-8">{t('home.trustEyebrow')}</Eyebrow>
            <h2 className="text-section text-white">
              {t('home.trustTitle')}<br />
              <span className="text-brand-lime">{t('home.trustAccent')}</span>
            </h2>
            <p className="text-white/70 text-lg md:text-xl mt-8 leading-relaxed max-w-prose-tight mx-auto">
              {t('home.trustBody')}
            </p>
          </motion.div>
        </div>
      </section>

      {/* ═══ FINAL CTA — minimal, confident ═══ */}
      <section className="bg-canvas-cream py-32 md:py-40">
        <div className="max-w-3xl mx-auto px-5 md:px-8 text-center">
          <motion.div {...fadeUp()}>
            <Eyebrow tone="lime" className="mb-6">{t('home.finalEyebrow')}</Eyebrow>
            <h2 className="text-section text-canvas-ink">
              {t('home.finalTitle')} <span className="text-brand-cyan">{t('home.finalAccent')}</span>
            </h2>
            <p className="text-canvas-ink/60 text-lg mt-6 max-w-prose-tight mx-auto">
              {t('home.finalSub')}
            </p>
            <div className="flex flex-wrap justify-center items-center gap-3 mt-10">
              <Button href={WA_QUOTE} target="_blank" rel="noopener noreferrer" variant="primary">
                <MessageCircle size={16} />
                {t('home.finalCta1')}
              </Button>
              <Button href="tel:7875580632" variant="secondary">
                <Phone size={15} />
                {t('home.finalCta2')}
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
}
