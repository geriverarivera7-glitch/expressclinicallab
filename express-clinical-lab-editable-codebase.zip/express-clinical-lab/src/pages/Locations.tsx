import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Helmet } from 'react-helmet-async';
import { MapPin, Phone, Clock, ArrowRight } from 'lucide-react';
import Layout from '../components/Layout';
import Eyebrow from '../components/Eyebrow';
import Button from '../components/Button';
import { fadeUp, heroFade } from '../lib/motion';

export default function LocationsPage() {
  const { t, i18n } = useTranslation();
  const lang = i18n.language;

  const branches = [
    {
      name: t('locations.loc1Name'),
      sub: t('locations.loc1Sub'),
      address: t('locations.loc1Address'),
      phone: t('locations.loc1Phone'),
      hours: t('locations.loc1Hours'),
      mapQuery: 'Express+Clinical+Lab+Plaza+Guayama+Mall+PR-3+Guayama+PR',
    },
    {
      name: t('locations.loc2Name'),
      sub: t('locations.loc2Sub'),
      address: t('locations.loc2Address'),
      phone: t('locations.loc2Phone'),
      hours: t('locations.loc2Hours'),
      mapQuery: 'Calle+Ashford+86+Sur+Guayama+PR',
    },
  ];

  const areas = t('common.areas', { returnObjects: true }) as string[];

  return (
    <Layout>
      <Helmet>
        <title>Localidades – Express Clinical Lab</title>
        <meta name="description" content="Dos sucursales en Guayama y servicio a domicilio en el sureste de Puerto Rico." />
      </Helmet>

      {/* Hero */}
      <section className="bg-canvas-deep relative overflow-hidden">
        <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse 60% 50% at 50% 0%, #155749 0%, #0d3b35 50%, #082621 100%)' }} aria-hidden="true" />
        <div className="relative max-w-4xl mx-auto px-5 md:px-8 pt-40 md:pt-48 pb-24 md:pb-32 text-center">
          <motion.div {...heroFade()}>
            <Eyebrow tone="lime" className="mb-8">{t('locations.heroEyebrow')}</Eyebrow>
          </motion.div>
          <motion.h1 {...heroFade(0.12)} className="text-hero text-white">
            {t('locations.heroTitle')}<br />
            <span className="text-brand-lime">{t('locations.heroAccent')}</span>
          </motion.h1>
          <motion.p {...heroFade(0.24)} className="text-lg md:text-xl text-white/70 mt-8 max-w-prose-tight mx-auto">
            {t('locations.heroSub')}
          </motion.p>
        </div>
      </section>

      {/* Branch cards */}
      <section className="bg-white py-32 md:py-40">
        <div className="max-w-6xl mx-auto px-5 md:px-8">
          <motion.div {...fadeUp()} className="mb-16">
            <h2 className="text-section text-canvas-ink">{t('locations.branchesTitle')}</h2>
          </motion.div>

          <div className="space-y-12">
            {branches.map((b, i) => (
              <motion.div key={i} {...fadeUp(i * 0.1)}
                className="grid md:grid-cols-2 gap-8 md:gap-12 items-stretch"
              >
                <div className="bg-canvas-cream rounded-3xl p-8 md:p-10 border border-canvas-ink/5 flex flex-col">
                  <p className="eyebrow text-brand-lime mb-3">Sucursal {i + 1}</p>
                  <h3 className="font-display text-3xl md:text-4xl font-medium text-canvas-ink mb-1">{b.name}</h3>
                  <p className="text-canvas-ink/60 mb-6">{b.sub}</p>

                  <ul className="space-y-4 text-canvas-ink/70 flex-1">
                    <li className="flex gap-3 items-start">
                      <MapPin size={16} className="text-brand-lime mt-1 flex-shrink-0" />
                      <span>{b.address}</span>
                    </li>
                    <li className="flex gap-3 items-center">
                      <Phone size={16} className="text-brand-lime flex-shrink-0" />
                      <a href={`tel:${b.phone.replace(/-/g,'')}`} className="hover:text-canvas-ink transition-colors">{b.phone}</a>
                    </li>
                    <li className="flex gap-3 items-start">
                      <Clock size={16} className="text-brand-lime mt-1 flex-shrink-0" />
                      <span className="whitespace-pre-line">{b.hours}</span>
                    </li>
                  </ul>

                  <div className="flex gap-3 mt-8">
                    <Button href={`https://maps.google.com/?q=${b.mapQuery}`} target="_blank" rel="noopener noreferrer" variant="primary" size="sm">
                      {t('locations.directions')}
                    </Button>
                    <Button href={`tel:${b.phone.replace(/-/g,'')}`} variant="secondary" size="sm">
                      {t('locations.call')}
                    </Button>
                  </div>
                </div>

                <div className="rounded-3xl overflow-hidden border border-canvas-ink/8 min-h-[280px] md:min-h-0">
                  <iframe
                    title={b.name}
                    src={`https://maps.google.com/maps?q=${b.mapQuery}&output=embed`}
                    className="w-full h-full min-h-[280px]"
                    style={{ border: 0 }}
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    allowFullScreen
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* At-home coverage area */}
      <section className="bg-canvas-cream py-32 md:py-40">
        <div className="max-w-5xl mx-auto px-5 md:px-8">
          <motion.div {...fadeUp()} className="text-center mb-16">
            <Eyebrow tone="lime" className="mb-5">{t('locations.areasEyebrow')}</Eyebrow>
            <h2 className="text-section text-canvas-ink">
              {t('locations.areasTitle')} <span className="text-brand-cyan">{t('locations.areasAccent')}</span>
            </h2>
            <p className="text-canvas-ink/60 text-lg mt-6 max-w-prose-tight mx-auto">
              {t('locations.areasSub')}
            </p>
          </motion.div>

          <motion.div {...fadeUp(0.1)} className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-12">
            {areas.map((area, i) => (
              <div key={i} className="flex items-center gap-2.5 bg-white border border-canvas-ink/8 rounded-2xl px-5 py-4">
                <MapPin size={14} className="text-brand-lime flex-shrink-0" />
                <span className="text-canvas-ink font-medium text-[15px]">{area}</span>
              </div>
            ))}
          </motion.div>

          <motion.div {...fadeUp(0.2)} className="text-center">
            <Button href={`/${lang}/domicilio`} variant="primary">
              {t('locations.areasCta')} <ArrowRight size={15} />
            </Button>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
}
