import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Helmet } from 'react-helmet-async';
import { MessageCircle, ArrowRight } from 'lucide-react';
import Layout from '../components/Layout';
import Eyebrow from '../components/Eyebrow';
import Button from '../components/Button';
import { fadeUp, heroFade } from '../lib/motion';

const WA = 'https://wa.me/19392945372?text=Hola%2C%20quisiera%20información';

export default function AboutPage() {
  const { t, i18n } = useTranslation();
  const lang = i18n.language;

  const values = [
    { title: t('about.v1Title'), body: t('about.v1Body') },
    { title: t('about.v2Title'), body: t('about.v2Body') },
    { title: t('about.v3Title'), body: t('about.v3Body') },
  ];

  return (
    <Layout>
      <Helmet>
        <title>Nosotros – Express Clinical Lab</title>
        <meta name="description" content="Express Clinical Lab — laboratorio clínico familiar en Guayama, Puerto Rico, comprometido con la salud de nuestra comunidad." />
      </Helmet>

      {/* Hero — dark, minimal */}
      <section className="bg-canvas-deep relative overflow-hidden">
        <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse 60% 50% at 50% 0%, #155749 0%, #0d3b35 50%, #082621 100%)' }} aria-hidden="true" />
        <div className="relative max-w-4xl mx-auto px-5 md:px-8 pt-40 md:pt-48 pb-24 md:pb-32 text-center">
          <motion.div {...heroFade()}>
            <Eyebrow tone="lime" className="mb-8">{t('about.heroEyebrow')}</Eyebrow>
          </motion.div>
          <motion.h1 {...heroFade(0.12)} className="text-hero text-white">
            {t('about.heroTitle')}<br />
            <span className="text-brand-lime">{t('about.heroAccent')}</span>
          </motion.h1>
          <motion.p {...heroFade(0.24)} className="text-lg md:text-xl text-white/70 mt-8 max-w-prose-tight mx-auto">
            {t('about.heroSub')}
          </motion.p>
        </div>
      </section>

      {/* Story — long-form, white, generous reading width */}
      <section className="bg-white py-32 md:py-40">
        <div className="max-w-3xl mx-auto px-5 md:px-8">
          <motion.div {...fadeUp()}>
            <h2 className="text-section text-canvas-ink mb-12">{t('about.storyTitle')}</h2>
          </motion.div>
          <div className="space-y-6 text-canvas-ink/80 text-lg leading-relaxed">
            {[t('about.story1'), t('about.story2'), t('about.story3')].map((p, i) => (
              <motion.p key={i} {...fadeUp(i * 0.08)}>{p}</motion.p>
            ))}
          </div>
        </div>
      </section>

      {/* Values — clean three-column */}
      <section className="bg-canvas-cream py-32 md:py-40">
        <div className="max-w-6xl mx-auto px-5 md:px-8">
          <motion.div {...fadeUp()} className="max-w-2xl mb-16">
            <Eyebrow tone="lime" className="mb-5">{t('about.valuesEyebrow')}</Eyebrow>
            <h2 className="text-section text-canvas-ink">
              {t('about.valuesTitle')} <span className="text-canvas-ink/50">{t('about.valuesAccent')}</span>
            </h2>
          </motion.div>
          <div className="grid md:grid-cols-3 gap-12">
            {values.map((v, i) => (
              <motion.div key={i} {...fadeUp(i * 0.1)}>
                <div className="w-9 h-9 rounded-full bg-brand-lime/15 border border-brand-lime/30 flex items-center justify-center mb-5">
                  <span className="font-display font-medium text-canvas-ink text-sm">{i + 1}</span>
                </div>
                <h3 className="font-display text-2xl font-medium text-canvas-ink mb-3">{v.title}</h3>
                <p className="text-canvas-ink/60 leading-relaxed">{v.body}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Closing */}
      <section className="bg-white py-32 md:py-40">
        <div className="max-w-3xl mx-auto px-5 md:px-8 text-center">
          <motion.div {...fadeUp()}>
            <h2 className="text-section text-canvas-ink">
              {t('about.closingTitle')}<br />
              <span className="text-brand-cyan">{t('about.closingAccent')}</span>
            </h2>
            <p className="text-canvas-ink/60 text-lg md:text-xl mt-8 leading-relaxed max-w-prose-tight mx-auto">
              {t('about.closingBody')}
            </p>
            <div className="flex flex-wrap justify-center gap-3 mt-12">
              <Button href={WA} target="_blank" rel="noopener noreferrer" variant="primary">
                <MessageCircle size={16} />
                WhatsApp
              </Button>
              <Button href={`/${lang}/servicios`} variant="secondary">
                Servicios <ArrowRight size={15} />
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
}
