import { useState } from 'react';
import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Helmet } from 'react-helmet-async';
import { Check, Mail, Factory, Building2, HeartPulse, Stethoscope } from 'lucide-react';
import Layout from '../components/Layout';
import Eyebrow from '../components/Eyebrow';
import Button from '../components/Button';
import { fadeUp, heroFade } from '../lib/motion';

export default function ForBusinessesPage() {
  const { t } = useTranslation();
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    company: '', contact: '', role: '', phone: '', email: '',
    town: '', employees: '', service: '', date: '', notes: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('[Business request]', form);
    setSubmitted(true);
  };

  const forWho = [
    { icon: Factory,     title: t('businesses.for1Title'), body: t('businesses.for1Body') },
    { icon: Building2,   title: t('businesses.for2Title'), body: t('businesses.for2Body') },
    { icon: HeartPulse,  title: t('businesses.for3Title'), body: t('businesses.for3Body') },
    { icon: Stethoscope, title: t('businesses.for4Title'), body: t('businesses.for4Body') },
  ];

  const benefits = [
    t('businesses.b1'), t('businesses.b2'), t('businesses.b3'),
    t('businesses.b4'), t('businesses.b5'), t('businesses.b6'),
  ];

  const serviceOpts = t('businesses.formServiceOptions', { returnObjects: true }) as string[];
  const employeeOpts = t('businesses.formEmployeesOptions', { returnObjects: true }) as string[];

  const inputCls =
    'w-full px-4 py-3 rounded-2xl border border-canvas-ink/12 bg-white text-canvas-ink ' +
    'placeholder-canvas-ink/35 text-[15px] focus:outline-none focus:border-canvas-ink/40 ' +
    'transition-all duration-200';

  const labelCls = 'eyebrow text-canvas-ink/50 mb-2 block';

  return (
    <Layout>
      <Helmet>
        <title>Servicios para Empresas – Express Clinical Lab</title>
        <meta name="description" content="Servicios de laboratorio para empresas, industrias, fábricas y oficinas en el sureste de Puerto Rico." />
      </Helmet>

      {/* Hero */}
      <section className="bg-canvas-deep relative overflow-hidden">
        <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse 60% 50% at 50% 0%, #155749 0%, #0d3b35 50%, #082621 100%)' }} aria-hidden="true" />
        <div className="relative max-w-4xl mx-auto px-5 md:px-8 pt-40 md:pt-48 pb-24 md:pb-32 text-center">
          <motion.div {...heroFade()}>
            <Eyebrow tone="lime" className="mb-8">{t('businesses.heroEyebrow')}</Eyebrow>
          </motion.div>
          <motion.h1 {...heroFade(0.12)} className="text-hero text-white">
            {t('businesses.heroTitle')}<br />
            <span className="text-brand-lime">{t('businesses.heroAccent')}</span>
          </motion.h1>
          <motion.p {...heroFade(0.24)} className="text-lg md:text-xl text-white/70 mt-8 max-w-prose-tight mx-auto">
            {t('businesses.heroSub')}
          </motion.p>
          <motion.div {...heroFade(0.36)} className="mt-12">
            <Button href="#proposal" variant="lime">
              {t('businesses.heroCta')}
            </Button>
          </motion.div>
        </div>
      </section>

      {/* For Who */}
      <section className="bg-white py-32 md:py-40">
        <div className="max-w-6xl mx-auto px-5 md:px-8">
          <motion.div {...fadeUp()} className="max-w-2xl mb-16">
            <Eyebrow tone="lime" className="mb-5">{t('businesses.forWhoEyebrow')}</Eyebrow>
            <h2 className="text-section text-canvas-ink">
              {t('businesses.forWhoTitle')}<br />
              <span className="text-canvas-ink/50">{t('businesses.forWhoAccent')}</span>
            </h2>
          </motion.div>
          <div className="grid sm:grid-cols-2 gap-6 md:gap-8">
            {forWho.map((w, i) => {
              const Icon = w.icon;
              return (
                <motion.div key={i} {...fadeUp(i * 0.08)}
                  className="bg-canvas-cream rounded-3xl p-8 md:p-10 border border-canvas-ink/5"
                >
                  <div className="w-11 h-11 rounded-full bg-brand-lime/15 border border-brand-lime/30 flex items-center justify-center mb-6">
                    <Icon size={18} className="text-brand-lime-dark" strokeWidth={1.75} />
                  </div>
                  <h3 className="font-display text-2xl font-medium text-canvas-ink mb-3">{w.title}</h3>
                  <p className="text-canvas-ink/60 leading-relaxed">{w.body}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="bg-canvas-cream py-32 md:py-40">
        <div className="max-w-6xl mx-auto px-5 md:px-8 grid md:grid-cols-2 gap-16">
          <motion.div {...fadeUp()}>
            <Eyebrow tone="lime" className="mb-5">{t('businesses.benefitsEyebrow')}</Eyebrow>
            <h2 className="text-section text-canvas-ink">
              {t('businesses.benefitsTitle')}<br />
              <span className="text-canvas-ink/50">{t('businesses.benefitsAccent')}</span>
            </h2>
          </motion.div>
          <motion.div {...fadeUp(0.1)} className="space-y-4">
            {benefits.map((b, i) => (
              <div key={i} className="flex items-start gap-3 border-b border-canvas-ink/8 pb-4 last:border-0">
                <div className="w-6 h-6 rounded-full bg-brand-lime/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Check size={12} className="text-brand-lime-dark" strokeWidth={3} />
                </div>
                <p className="text-canvas-ink text-base md:text-lg">{b}</p>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Form */}
      <section id="proposal" className="bg-white py-32 md:py-40">
        <div className="max-w-3xl mx-auto px-5 md:px-8">
          <motion.div {...fadeUp()} className="mb-12">
            <Eyebrow tone="lime" className="mb-5">{t('businesses.formEyebrow')}</Eyebrow>
            <h2 className="text-section text-canvas-ink mb-4">
              {t('businesses.formTitle')} <span className="text-brand-cyan">{t('businesses.formAccent')}</span>
            </h2>
            <p className="text-canvas-ink/60 text-lg leading-relaxed">{t('businesses.formSub')}</p>
          </motion.div>

          {submitted ? (
            <motion.div
              initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
              className="bg-canvas-cream rounded-3xl border border-brand-lime/30 p-10 text-center"
            >
              <div className="w-14 h-14 rounded-full bg-brand-lime/20 flex items-center justify-center mx-auto mb-5">
                <Check size={24} className="text-brand-lime-dark" strokeWidth={2.5} />
              </div>
              <p className="font-display text-2xl font-medium text-canvas-ink">
                {t('businesses.formSuccess')}
              </p>
            </motion.div>
          ) : (
            <motion.form {...fadeUp(0.1)} onSubmit={handleSubmit}
              className="bg-canvas-cream rounded-3xl border border-canvas-ink/8 p-8 md:p-10 space-y-6"
            >
              <div className="grid md:grid-cols-2 gap-5">
                <div>
                  <label className={labelCls}>{t('businesses.formCompany')}</label>
                  <input required value={form.company} onChange={e=>setForm(f=>({...f, company:e.target.value}))} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>{t('businesses.formContact')}</label>
                  <input required value={form.contact} onChange={e=>setForm(f=>({...f, contact:e.target.value}))} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>{t('businesses.formRole')}</label>
                  <input value={form.role} onChange={e=>setForm(f=>({...f, role:e.target.value}))} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>{t('businesses.formPhone')}</label>
                  <input required type="tel" value={form.phone} onChange={e=>setForm(f=>({...f, phone:e.target.value}))} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>{t('businesses.formEmail')}</label>
                  <input required type="email" value={form.email} onChange={e=>setForm(f=>({...f, email:e.target.value}))} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>{t('businesses.formTown')}</label>
                  <input required value={form.town} onChange={e=>setForm(f=>({...f, town:e.target.value}))} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>{t('businesses.formEmployees')}</label>
                  <select required value={form.employees} onChange={e=>setForm(f=>({...f, employees:e.target.value}))} className={inputCls}>
                    <option value="">—</option>
                    {employeeOpts.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className={labelCls}>{t('businesses.formDate')}</label>
                  <input type="date" value={form.date} onChange={e=>setForm(f=>({...f, date:e.target.value}))} className={inputCls} />
                </div>
              </div>

              <div>
                <label className={labelCls}>{t('businesses.formServiceType')}</label>
                <select required value={form.service} onChange={e=>setForm(f=>({...f, service:e.target.value}))} className={inputCls}>
                  <option value="">—</option>
                  {serviceOpts.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>

              <div>
                <label className={labelCls}>{t('businesses.formNotes')}</label>
                <textarea rows={4} value={form.notes} onChange={e=>setForm(f=>({...f, notes:e.target.value}))} className={`${inputCls} resize-none`} />
              </div>

              <Button type="submit" variant="primary" className="w-full justify-center">
                {t('businesses.formSubmit')}
              </Button>

              <div className="border-t border-canvas-ink/8 pt-5 text-center">
                <p className="text-canvas-ink/50 text-sm mb-2">{t('businesses.directEmail')}</p>
                <a href="mailto:jlriveraandsons@gmail.com" className="inline-flex items-center gap-2 text-canvas-ink font-medium hover:text-brand-cyan transition-colors">
                  <Mail size={15} />
                  {t('businesses.businessEmail')}
                </a>
              </div>
            </motion.form>
          )}
        </div>
      </section>
    </Layout>
  );
}
