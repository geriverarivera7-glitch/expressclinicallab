import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Helmet } from 'react-helmet-async';
import { MessageCircle } from 'lucide-react';
import Layout from '../components/Layout';
import Eyebrow from '../components/Eyebrow';
import Button from '../components/Button';
import { fadeUp, heroFade } from '../lib/motion';

const WA = 'https://wa.me/19392945372?text=Hola%2C%20quisiera%20verificar%20disponibilidad%20de%20una%20prueba';

export default function TestsPage() {
  const { t } = useTranslation();

  const categories = [
    { title: t('tests.category1Title'), body: t('tests.category1Body') },
    { title: t('tests.category2Title'), body: t('tests.category2Body') },
    { title: t('tests.category3Title'), body: t('tests.category3Body') },
    { title: t('tests.category4Title'), body: t('tests.category4Body') },
    { title: t('tests.category5Title'), body: t('tests.category5Body') },
    { title: t('tests.category6Title'), body: t('tests.category6Body') },
    { title: t('tests.category7Title'), body: t('tests.category7Body') },
    { title: t('tests.category8Title'), body: t('tests.category8Body') },
  ];

  return (
    <Layout>
      <Helmet>
        <title>Pruebas – Express Clinical Lab</title>
        <meta name="description" content="Variedad de pruebas de laboratorio para diagnóstico, seguimiento y cuidado preventivo. Consulta disponibilidad por WhatsApp." />
      </Helmet>

      {/* Hero */}
      <section className="bg-canvas-deep relative overflow-hidden">
        <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse 60% 50% at 50% 0%, #155749 0%, #0d3b35 50%, #082621 100%)' }} aria-hidden="true" />
        <div className="relative max-w-4xl mx-auto px-5 md:px-8 pt-40 md:pt-48 pb-24 md:pb-32 text-center">
          <motion.div {...heroFade()}>
            <Eyebrow tone="lime" className="mb-8">{t('tests.heroEyebrow')}</Eyebrow>
          </motion.div>
          <motion.h1 {...heroFade(0.12)} className="text-hero text-white">
            {t('tests.heroTitle')}<br />
            <span className="text-brand-lime">{t('tests.heroAccent')}</span>
          </motion.h1>
          <motion.p {...heroFade(0.24)} className="text-lg md:text-xl text-white/70 mt-8 max-w-prose-65 mx-auto leading-relaxed">
            {t('tests.heroSub')}
          </motion.p>
        </div>
      </section>

      {/* Categories grid */}
      <section className="bg-white py-32 md:py-40">
        <div className="max-w-6xl mx-auto px-5 md:px-8">
          <div className="grid md:grid-cols-2 gap-x-12 gap-y-12">
            {categories.map((cat, i) => (
              <motion.div key={i} {...fadeUp(i * 0.05)} className="border-l-2 border-brand-lime/40 pl-6 py-1">
                <h3 className="font-display text-xl md:text-2xl font-medium text-canvas-ink mb-2">
                  {cat.title}
                </h3>
                <p className="text-canvas-ink/60 leading-relaxed">{cat.body}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-canvas-cream py-32 md:py-40">
        <div className="max-w-3xl mx-auto px-5 md:px-8 text-center">
          <motion.div {...fadeUp()}>
            <h2 className="text-section text-canvas-ink">{t('tests.ctaTitle')}</h2>
            <p className="text-canvas-ink/60 text-lg mt-6 max-w-prose-tight mx-auto">
              {t('tests.ctaBody')}
            </p>
            <div className="mt-10">
              <Button href={WA} target="_blank" rel="noopener noreferrer" variant="primary">
                <MessageCircle size={16} />
                {t('tests.ctaButton')}
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
}
