import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Helmet } from 'react-helmet-async';
import { MessageCircle, Phone, Mail, Plus, Check } from 'lucide-react';
import Layout from '../components/Layout';
import Eyebrow from '../components/Eyebrow';
import Button from '../components/Button';
import { fadeUp, heroFade } from '../lib/motion';

export default function ContactPage() {
  const { t } = useTranslation();
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: '', phone: '', email: '', reason: '', message: '' });
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('[Contact form]', form);
    setSubmitted(true);
  };

  const channels = [
    { icon: MessageCircle, title: t('contact.ch1Title'), sub: t('contact.ch1Sub'), val: t('contact.ch1Val'), cta: t('contact.ch1Cta'), href: 'https://wa.me/19392945372', highlight: true },
    { icon: Phone,         title: t('contact.ch2Title'), sub: t('contact.ch2Sub'), val: t('contact.ch2Val'), cta: t('contact.ch2Cta'), href: 'tel:7875580632' },
    { icon: Mail,          title: t('contact.ch3Title'), sub: t('contact.ch3Sub'), val: t('contact.ch3Val'), cta: t('contact.ch3Cta'), href: 'mailto:expressclinicallab@gmail.com' },
    { icon: Mail,          title: t('contact.ch4Title'), sub: t('contact.ch4Sub'), val: t('contact.ch4Val'), cta: t('contact.ch4Cta'), href: 'mailto:jlriveraandsons@gmail.com' },
  ];

  const reasonOpts = t('contact.formReasonOptions', { returnObjects: true }) as string[];

  const faqs = [
    { q: t('contact.faq1Q'), a: t('contact.faq1A') },
    { q: t('contact.faq2Q'), a: t('contact.faq2A') },
    { q: t('contact.faq3Q'), a: t('contact.faq3A') },
    { q: t('contact.faq4Q'), a: t('contact.faq4A') },
    { q: t('contact.faq5Q'), a: t('contact.faq5A') },
  ];

  const inputCls =
    'w-full px-4 py-3 rounded-2xl border border-canvas-ink/12 bg-white text-canvas-ink ' +
    'placeholder-canvas-ink/35 text-[15px] focus:outline-none focus:border-canvas-ink/40 ' +
    'transition-all duration-200';

  const labelCls = 'eyebrow text-canvas-ink/50 mb-2 block';

  return (
    <Layout>
      <Helmet>
        <title>Contacto – Express Clinical Lab</title>
        <meta name="description" content="WhatsApp, teléfono, email o formulario — elige el canal que prefieras y te respondemos rápido." />
      </Helmet>

      {/* Hero */}
      <section className="bg-canvas-deep relative overflow-hidden">
        <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse 60% 50% at 50% 0%, #155749 0%, #0d3b35 50%, #082621 100%)' }} aria-hidden="true" />
        <div className="relative max-w-4xl mx-auto px-5 md:px-8 pt-40 md:pt-48 pb-24 md:pb-32 text-center">
          <motion.div {...heroFade()}>
            <Eyebrow tone="lime" className="mb-8">{t('contact.heroEyebrow')}</Eyebrow>
          </motion.div>
          <motion.h1 {...heroFade(0.12)} className="text-hero text-white">
            {t('contact.heroTitle')}<br />
            <span className="text-brand-lime">{t('contact.heroAccent')}</span>
          </motion.h1>
          <motion.p {...heroFade(0.24)} className="text-lg md:text-xl text-white/70 mt-8 max-w-prose-tight mx-auto">
            {t('contact.heroSub')}
          </motion.p>
        </div>
      </section>

      {/* Channels grid */}
      <section className="bg-white py-32 md:py-40">
        <div className="max-w-6xl mx-auto px-5 md:px-8">
          <motion.div {...fadeUp()} className="mb-16">
            <h2 className="text-section text-canvas-ink">{t('contact.channelsTitle')}</h2>
          </motion.div>

          <div className="grid sm:grid-cols-2 gap-5">
            {channels.map((ch, i) => {
              const Icon = ch.icon;
              return (
                <motion.a
                  key={i}
                  {...fadeUp(i * 0.06)}
                  href={ch.href}
                  target={ch.href.startsWith('http') ? '_blank' : undefined}
                  rel="noopener noreferrer"
                  className={`group block rounded-3xl p-8 md:p-10 border transition-all duration-500 ease-apple hover:-translate-y-1 ${
                    ch.highlight
                      ? 'bg-canvas-ink text-white border-canvas-ink hover:bg-canvas-deep'
                      : 'bg-canvas-cream text-canvas-ink border-canvas-ink/8 hover:border-canvas-ink/20'
                  }`}
                >
                  <div className="flex items-start justify-between mb-8">
                    <div className={`w-11 h-11 rounded-full flex items-center justify-center ${ch.highlight ? 'bg-brand-lime/20' : 'bg-brand-lime/15 border border-brand-lime/30'}`}>
                      <Icon size={18} className={ch.highlight ? 'text-brand-lime' : 'text-brand-lime-dark'} strokeWidth={1.75} />
                    </div>
                    <p className={`eyebrow ${ch.highlight ? 'text-white/40' : 'text-canvas-ink/40'}`}>{ch.title}</p>
                  </div>
                  <p className={`text-sm mb-2 ${ch.highlight ? 'text-white/60' : 'text-canvas-ink/50'}`}>{ch.sub}</p>
                  <p className="font-display text-2xl md:text-3xl font-medium mb-6 break-all">{ch.val}</p>
                  <span className={`inline-flex items-center gap-1.5 text-sm font-medium ${ch.highlight ? 'text-brand-lime' : 'text-canvas-ink group-hover:text-brand-cyan'} transition-colors`}>
                    {ch.cta} →
                  </span>
                </motion.a>
              );
            })}
          </div>
        </div>
      </section>

      {/* General form */}
      <section className="bg-canvas-cream py-32 md:py-40">
        <div className="max-w-3xl mx-auto px-5 md:px-8">
          <motion.div {...fadeUp()} className="mb-12">
            <Eyebrow tone="lime" className="mb-5">{t('contact.formEyebrow')}</Eyebrow>
            <h2 className="text-section text-canvas-ink">
              {t('contact.formTitle')} <span className="text-brand-cyan">{t('contact.formAccent')}</span>
            </h2>
          </motion.div>

          {submitted ? (
            <motion.div
              initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-3xl border border-brand-lime/30 p-10 text-center"
            >
              <div className="w-14 h-14 rounded-full bg-brand-lime/20 flex items-center justify-center mx-auto mb-5">
                <Check size={24} className="text-brand-lime-dark" strokeWidth={2.5} />
              </div>
              <p className="font-display text-2xl font-medium text-canvas-ink">{t('contact.formSuccess')}</p>
            </motion.div>
          ) : (
            <motion.form {...fadeUp(0.1)} onSubmit={handleSubmit}
              className="bg-white rounded-3xl border border-canvas-ink/8 p-8 md:p-10 space-y-6"
            >
              <div className="grid md:grid-cols-2 gap-5">
                <div>
                  <label className={labelCls}>{t('contact.formName')}</label>
                  <input required value={form.name} onChange={e=>setForm(f=>({...f, name:e.target.value}))} className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>{t('contact.formPhone')}</label>
                  <input required type="tel" value={form.phone} onChange={e=>setForm(f=>({...f, phone:e.target.value}))} className={inputCls} />
                </div>
                <div className="md:col-span-2">
                  <label className={labelCls}>{t('contact.formEmail')}</label>
                  <input type="email" value={form.email} onChange={e=>setForm(f=>({...f, email:e.target.value}))} className={inputCls} />
                </div>
                <div className="md:col-span-2">
                  <label className={labelCls}>{t('contact.formReason')}</label>
                  <select required value={form.reason} onChange={e=>setForm(f=>({...f, reason:e.target.value}))} className={inputCls}>
                    <option value="">—</option>
                    {reasonOpts.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
              </div>

              <div>
                <label className={labelCls}>{t('contact.formMessage')}</label>
                <textarea required rows={5} value={form.message} onChange={e=>setForm(f=>({...f, message:e.target.value}))} className={`${inputCls} resize-none`} />
              </div>

              <p className="text-canvas-ink/40 text-xs italic leading-relaxed border-t border-canvas-ink/8 pt-5">
                {t('contact.formDisclaimer')}
              </p>

              <Button type="submit" variant="primary" className="w-full justify-center">
                {t('contact.formSubmit')}
              </Button>
            </motion.form>
          )}
        </div>
      </section>

      {/* FAQ */}
      <section className="bg-white py-32 md:py-40">
        <div className="max-w-3xl mx-auto px-5 md:px-8">
          <motion.div {...fadeUp()} className="mb-12">
            <h2 className="text-section text-canvas-ink">
              {t('contact.faqTitle')} <span className="text-canvas-ink/50">{t('contact.faqAccent')}</span>
            </h2>
          </motion.div>

          <div className="border-t border-canvas-ink/10">
            {faqs.map((f, i) => {
              const isOpen = openFaq === i;
              return (
                <motion.div key={i} {...fadeUp(i * 0.04)} className="border-b border-canvas-ink/10">
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : i)}
                    className="w-full text-left py-6 flex items-center justify-between gap-6 group"
                  >
                    <span className="font-display text-lg md:text-xl font-medium text-canvas-ink">
                      {f.q}
                    </span>
                    <Plus
                      size={20}
                      className={`text-canvas-ink/40 group-hover:text-canvas-ink flex-shrink-0 transition-transform duration-300 ease-apple ${isOpen ? 'rotate-45' : ''}`}
                      strokeWidth={1.5}
                    />
                  </button>
                  <AnimatePresence initial={false}>
                    {isOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                        className="overflow-hidden"
                      >
                        <p className="text-canvas-ink/70 leading-relaxed pb-6 max-w-prose-65">{f.a}</p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
    </Layout>
  );
}
